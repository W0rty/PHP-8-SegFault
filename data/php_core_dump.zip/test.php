<?php
include("phar://phar.phar");
include("phar://phar.phar");
